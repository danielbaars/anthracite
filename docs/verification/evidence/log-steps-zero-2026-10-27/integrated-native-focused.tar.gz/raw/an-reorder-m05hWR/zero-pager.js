const fs = require('fs');
fs.appendFileSync("/var/folders/p8/b_05tm755b34yb9h11zzqp1c0000gn/T/anthracite-suite-zN8yQf/an-reorder-m05hWR/pager-log", JSON.stringify({args:process.argv.slice(2),cwd:process.cwd()})+'\n');
fs.writeFileSync("/var/folders/p8/b_05tm755b34yb9h11zzqp1c0000gn/T/anthracite-suite-zN8yQf/an-reorder-m05hWR/pager-input", fs.readFileSync(0));
process.stdout.write('ZERO_PAGED_ONCE\n');