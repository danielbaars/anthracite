const fs = require('fs');
const path = require('path');
const { FreezeCliFixture } = require('/private/tmp/anthracite-log-implementation/ci-fix/apps/cli/dist/test/lib/fixtures/freeze_cli');
const { getTestCliCommand } = require('/private/tmp/anthracite-log-implementation/ci-fix/apps/cli/dist/src/lib/utils/test_cli_command');
const fixture = new FreezeCliFixture();
const quote = (value) => `'${value.replace(/'/g, `'"'"'`)}'`;
const read = () => ({
  dates: fixture.git(['for-each-ref', '--sort=-committerdate', '--format=%(refname:short) %(committerdate:iso8601-strict) %(authordate:iso8601-strict)', 'refs/heads/']),
});
try {
  fixture.branch('z-sibling', 'base');
  fixture.git(['switch', 'child']);
  fixture.env.GIT_COMMITTER_DATE = '2030-01-01T00:00:00Z';
  fixture.git(['commit', '--amend', '--no-edit']);
  delete fixture.env.GIT_COMMITTER_DATE;
  const before = read();
  fixture.ok(['restack', '--upstack']);
  fixture.git(['switch', 'base']);
  const after = read();
  const child = fixture.git(['rev-parse', 'child']);
  const cli = getTestCliCommand(['freeze', 'z-sibling', '--no-interactive']);
  const marker = path.join(fixture.root, 'hook-fired');
  fs.writeFileSync(path.join(fixture.repo, '.git', 'hooks', 'post-rewrite'),
    '#!/bin/sh\ninput=$(cat)\ncase "$input" in\n*' + child + '*)\n' +
    'printf fired >> ' + quote(marker) + '\n' + cli.map(quote).join(' ') + '\n;;\nesac\n',
    {mode:0o755});
  const result = fixture.run(['move', '-o', 'other']);
  console.log(JSON.stringify({before,after,status:result.status,stdout:result.stdout,stderr:result.stderr,hookFired:fs.existsSync(marker),finalDates:fixture.git(['for-each-ref','--sort=-committerdate','--format=%(refname:short) %(committerdate:iso8601-strict)','refs/heads/'])},null,2));
} finally {fixture.cleanup();}
