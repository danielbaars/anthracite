const fs = require('fs');
fs.appendFileSync("/private/tmp/anthracite-log-implementation/test-tmp/an-reorder-8OvuWv/pager-log", JSON.stringify({args:process.argv.slice(2),cwd:process.cwd()})+'\n');
process.stdout.write('ZERO_PAGER_STOPPED\n');
process.exitCode=0;