const fs = require('fs');
fs.appendFileSync("/private/tmp/anthracite-log-implementation/test-tmp/an-reorder-936M9X/pager-log", JSON.stringify({args:process.argv.slice(2),cwd:process.cwd()})+'\n');
fs.writeFileSync("/private/tmp/anthracite-log-implementation/test-tmp/an-reorder-936M9X/pager-input", fs.readFileSync(0));
process.stdout.write('ZERO_PAGED_ONCE\n');