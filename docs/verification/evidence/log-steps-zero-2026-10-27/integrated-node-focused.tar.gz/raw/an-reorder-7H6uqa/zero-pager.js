const fs = require('fs');
fs.appendFileSync("/var/folders/p8/b_05tm755b34yb9h11zzqp1c0000gn/T/anthracite-suite-vBYcHC/an-reorder-7H6uqa/pager-log", JSON.stringify({args:process.argv.slice(2),cwd:process.cwd()})+'\n');
process.stdout.write('ZERO_PAGER_STOPPED\n');
process.exitCode=23;